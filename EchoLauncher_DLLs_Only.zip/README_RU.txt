Это все ШЕСТЬ DLL, которые удалось извлечь из конкретного EchoLauncher-Setup.exe.
Они служебные DLL NSIS-УСТАНОВЩИКА, а НЕ DLL, внедряемые в Fortnite.
Имена DLL игры найдены в коде, но сами байты в данном установщике отсутствуют.
Полный архив с кодом, EXE и ресурсами: EchoLauncher_All_Extracted_Files_and_Code.zip.
