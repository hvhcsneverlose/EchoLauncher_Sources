# Echo Launcher — максимально глубокий офлайновый статический разбор

**Входной образец:** `EchoLauncher-Setup.exe` из загрузки пользователя; установленный объект `echo-launcher.exe` извлечён из установщика ранее. В этом анализе не запускались EXE и не подключалась игра/сервер.

**Проверенный SHA-256 основного EXE:** `efb196a9970cf8bb9ccc2342460dbb4e152028053af7325ee3092df7c5e8b59e`.

## Структура

- `00_README_AND_REPORTS/` — инструкция, список Tauri-команд, восстановленный на основе IL псевдокод C# и выводы.
- `01_Frontend_Deobfuscated/` — **17** декодированных JS-файлов; **8 151** обращения к обфусцированным строкам заменены литералами (только статическая подстановка, без выполнения кода). `node --check` прошёл для всех 17 файлов. Ротационные IIFE оставлены для сохранения поведения; возможно дальнейшее переименование переменных вручную.
- `02_DotNet_FortniteLauncher/` — **42** метода в метаданных: **34** тела методов разобраны в IL, ещё **8** методов — внешние/без IL-тела. Метаданные **10** типов, имена методов, список внешних ссылок. Ошибок чтения IL нет. Это не идентичный авторскому C# код.
- `03_Rust_Native/` — **полный** дизассемблерный вывод `.text` (**1 537 888** строк, ~55.8 MB); функции из `.pdata` (**11 570** записей), **440** импортов, **47 820** ASCII и **147** UTF-16 строк, карта перекрёстных ссылок и **78** адресно выбранных фрагментов функций. Это **ассемблер**, не восстановленные исходники Rust.
- `04_Original_Extracted_Assets/` — **46** исходных ресурсов Tauri из EXE, включая JS/CSS/графику/`FortniteLauncher.exe` и распакованный основной EXE (для сверки).
- `05_Reproduce_ReadOnly/` — Python-скрипты статического анализа, работают с файлами, не запускают EXE. `recover_rust_native.py` требует предварительного создания ASM через `objdump`.

## Проверенный функционал

**От .NET-помощника (не только по строкам):**
1. Проверяет наличие `FortniteClient-Win64-Shipping.exe`.
2. Запускает Fortnite с аргументами `-noeac -nobe -fltoken=none` (как часть командной строки).
3. По определённым событиям из стандартного вывода игры создаёт Patcher и запускает его.
4. Читает память целевого процесса, ищет сигнатуры и может записать 12 байт в память процесса через `WriteProcessMemory` при режиме `-NOSSLPINNING`. Это реально отключает/меняет часть проверки SSL, и может создавать риск безопасности.
5. Это не доказывает, что каждый режим включён во всех сценариях запуска.

**От Rust-части (достоверно обнаруженные строки и адреса функций):**
- Логика размещения в Win64 связана с `xinput1_3.dll`, сохранением оригинального DLL в `xinput1_3_echo.dll`, `sinum.dll`, `echo-client.dll`.
- Упомянуты `vivoxsdk_x64_original.dll`, `.forced-paks-manifest.json`, `.paks-manifest.json`, `FortniteGame/Saved/Config/WindowsClient/Engine.ini`.
- Содержатся операции контроля состояния игры, обновления, проверки файлов, сбора диагностических логов.
- В `.rdata` есть команды `launch_game`, `verify_game`, `install_mod_cmd`, `upload_diagnostic_logs` и другие (см. карту). Эти строки не доказывают, что каждый путь всегда исполняется.

## Как читать

1. Для интерфейса открывайте `01_Frontend_Deobfuscated/app.js`, `tauri-bridge.js`, `tab-mods.js`, `tab-builds.js`.
2. Все вызовы JS → Rust смотрите в `00_README_AND_REPORTS/TAURI_COMMANDS.txt`.
3. Для .NET читайте `02_DotNet_FortniteLauncher/FortniteLauncher_all_methods.il`; функции `FortniteLauncher.Patcher::NoSSLPinning`, `FortniteLauncher.Program::Main`.
4. Для Rust сначала смотрите `03_Rust_Native/interesting_string_xrefs.tsv`; адрес функции ищите в `selected_functions_disassembly.asm`, затем в `echo_launcher_x64_all_text.asm`.
5. Адреса виртуальные (`0x140...`); это статические адреса без ASLR в запущенном процессе. `native_functions.csv` содержит границы, полученные из `.pdata` (не гарантирует полное покрытие ассемблерных функций).
6. Реальные изменения файлов после запуска и загружаемые позже DLL неизвестны; нужно динамическое наблюдение в виртуальной машине. Нельзя называть этот архив полными оригинальными исходниками или полноценной декомпиляцией Rust.

## Повторение

Для native: `objdump -d -j .text -M intel --no-show-raw-insn echo-launcher.exe > echo_launcher_x64_all_text.asm`.

Для анализа функций: `python recover_rust_native.py echo-launcher.exe echo_launcher_x64_all_text.asm output_folder`.

Для .NET: `python recover_dotnet_il.py FortniteLauncher.exe output_folder`.

Для JS: `python deobfuscate_echo_js.py path/to/extracted/frontend path/to/output`.

Для статического извлечения Brotli: `python extract_tauri_frontend.py echo-launcher.exe extracted_output` (нужен Python-модуль `brotli`).

Проверка синтаксиса JS: `node --check your.js` (не запускает само приложение).

**Ограничения:** без исходников Rust и PDB нельзя автоматически получить оригинальные `*.rs`, комментарии, названия внутренних Rust-функций и код серверной части; вся нативная дизассемблировка включает сторонние библиотеки Tauri и Rust, многие строки относятся к зависимостям. Динамическое поведение не проверялось. Не исполняйте неподписанные неизвестные бинарные файлы в основной Windows.
