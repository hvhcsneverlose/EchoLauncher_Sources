#!/usr/bin/env python3
"""Static string-array decoding; does not execute any code from input JS."""
import ast,re,json,pathlib,sys,collections
src=pathlib.Path(sys.argv[1]); dst=pathlib.Path(sys.argv[2]);dst.mkdir(parents=True,exist_ok=True)
reps=[]
for f in sorted(src.glob('*.js')):
    s=f.read_text(encoding='utf-8'); n=len(s)
    array_func=re.search(r'function\s+(_\w+_[a-z])\(\)\{const\s+\w+=\[',s)
    if not array_func:
        print('NO ARRAY',f.name);continue
    arrayfn=array_func.group(1)
    mat=re.search(r'function\s+(_\w+_[a-z])\(a,b\)\{a=a-(0x[\da-f]+);',s)
    if not mat:
        print('NO DECODER',f.name); continue
    decoder=mat.group(1); base=int(mat.group(2),16)
    j=s.find('[',array_func.start()); k=s.find('];',j)
    arr=ast.literal_eval(s[j:k+1]);L=len(arr)
    rotation_pattern=re.search(r'\(function\(a,b\)\{.*?const\s+d=(.*?);if\(d===b\).*?\}\('+re.escape(arrayfn)+r',(0x[\da-f]+)\)\);',s,re.S)
    if not rotation_pattern:
        print('NO ROTATOR',f.name);continue
    expr=rotation_pattern.group(1)
    target=int(rotation_pattern.group(2),16)
    calls=list(re.finditer(r'parseInt\(\w+\((0x[\da-f]+)\)\)',expr))
    cmd=[]; pos=0
    for call in calls:
        cmd.append(expr[pos:call.start()]);cmd.append('p{}'.format(len(cmd)//2));pos=call.end()
    cmd.append(expr[pos:]);formula=''.join(cmd)
    if not re.fullmatch(r'[\da-f\s.+\-*/()xp]+',formula):
        print('UNSAFE EXPRESSION', f.name,repr(formula[:100]));continue
    def js_parseint(v):
        z=re.match(r'^\s*([+-]?\d+)',v);return int(z.group(1)) if z else None
    offset=None
    for shift in range(L):
        ns={'p'+str(i):js_parseint(arr[(int(m.group(1),16)-base+shift)%L]) for i,m in enumerate(calls)}
        if None in ns.values():continue
        try:val=eval(formula,{'__builtins__':{}},ns)
        except (ZeroDivisionError,NameError):continue
        if abs(val-target)<0.001:offset=shift;break
    if offset is None:
        print('NO OFFSET',f.name,'L',L,'target',target);continue
    aliases={decoder}
    for x in re.finditer(r'(?:const|let|var)\s+(\w+)\s*=\s*'+re.escape(decoder)+r'(?=\s*[,;])',s):aliases.add(x.group(1))
    # alias list can chain a=b, b=original
    for i in range(3):
        for x in re.finditer(r'(?:const|let|var)\s+(\w+)\s*=\s*(\w+)(?=\s*[,;])',s):
            if x.group(2) in aliases:aliases.add(x.group(1))
    # aliases that are let assigned (context names), const F=decoder handled
    aliases=sorted(aliases,key=len,reverse=True)
    call_re=re.compile(r'(?<![A-Za-z0-9_$])('+ '|'.join(map(re.escape,aliases))+r')\((0x[\da-f]+)\)')
    bad=set();count=[0]
    def sub(m):
        i=int(m.group(2),16)-base
        if i<0 or i>=L:
            bad.add(m.group());return m.group()
        count[0]+=1
        return json.dumps(arr[(i+offset)%L],ensure_ascii=False)
    dec=call_re.sub(sub,s)
    (dst/f.name).write_text('// Static string-array recovery from embedded Echo Launcher JS. Original executable was NOT run.\n'+dec,encoding='utf-8')
    reps.append({'file':f.name,'source_bytes':n,'array_length':L,'rotations':offset,'index_base':hex(base),'aliases':aliases,'replaced_calls':count[0],'unreplaced':sorted(bad)})
    print(f.name,'rot',offset,'replaced',count[0],'aliases',len(aliases),'bad',len(bad))
(dst/'deobfuscation_report.json').write_text(json.dumps(reps,indent=2,ensure_ascii=False),encoding='utf-8')
