#!/usr/bin/env python3
"""Native x64 PE map: .pdata function bounds, imports, strings and xrefs from objdump. No execution."""
from pathlib import Path
import re,struct,hashlib,bisect,json,csv,collections,sys
pe=Path(sys.argv[1]);asm=Path(sys.argv[2]);out=Path(sys.argv[3]);out.mkdir(parents=True,exist_ok=True)
b=pe.read_bytes();p=struct.unpack_from('<I',b,0x3c)[0];coff=p+4;opt=coff+20;mag=struct.unpack_from('<H',b,opt)[0];ibase=struct.unpack_from('<Q' if mag==0x20b else '<I',b,opt+24 if mag==0x20b else opt+28)[0];dir=opt+(112 if mag==0x20b else 96);sects=[]
for j in range(struct.unpack_from('<H',b,coff+2)[0]):
 s=opt+struct.unpack_from('<H',b,coff+16)[0]+j*40
 name=b[s:s+8].split(b'\0')[0].decode('ascii','replace');vsz,rva,rawlen,raw=struct.unpack_from('<IIII',b,s+8)
 sects.append(dict(name=name,rva=rva,file_offset=raw,raw_bytes=rawlen,memory_bytes=vsz,va=ibase+rva))
def from_rva(rva):
 for s in sects:
  if s['rva']<=rva<s['rva']+max(s['memory_bytes'],s['raw_bytes']):return s['file_offset']+rva-s['rva']
 return None
def get_ascii_va(va,limit=250):
 o=from_rva(va-ibase)
 if o is None or o>=len(b):return ''
 data=b[o:o+limit]
 z=0
 while z<len(data) and 32<=data[z]<=126 or (z<len(data) and data[z] in (9,10,13)):
  z+=1
 return data[:z].decode('ascii','replace') if z>=6 else ''
# runtime function table .pdata
pdata=next(s for s in sects if s['name']=='.pdata')
start=pdata['file_offset'];end=start+pdata['raw_bytes'];ranges=[]
for j in range(start,end-11,12):
 a,b2,x=struct.unpack_from('<III',b,j)
 if a<b2 and a>=0x1000 and b2<=0x1695000:ranges.append((a+ibase,b2+ibase,x))
ranges.sort();unique=[]
for r in ranges:
 if not unique or r[:2]!=unique[-1][:2]:unique.append(r)
starts=[r[0] for r in unique]
(out/'native_functions.csv').write_text('index,start_va,end_va,size,unwind_rva\n'+''.join(f'{i},0x{a:x},0x{bb:x},{bb-a},0x{unw:x}\n' for i,(a,bb,unw) in enumerate(unique,1)),encoding='utf-8')
# imports
import_rva,import_size=struct.unpack_from('<II',b,dir+8);pos=from_rva(import_rva);imports=[]
while pos is not None and pos+20<=len(b):
 lookup,ts,chain,namerva,iat=struct.unpack_from('<IIIII',b,pos)
 if not (lookup or namerva):break
 so=from_rva(namerva)
 if so is None:break
 dll=b[so:b.index(b'\0',so)].decode('ascii','replace');table=from_rva(lookup or iat);arr=[]
 if table is None:break
 for z in range(300):
  v=struct.unpack_from('<Q' if mag==0x20b else '<I',b,table+z*(8 if mag==0x20b else 4))[0]
  if not v:break
  if v>>(63 if mag==0x20b else 31):name='ordinal:'+str(v&0xffff)
  else:
   t=from_rva(v); name=b[t+2:b.index(b'\0',t+2)].decode('ascii','replace') if t is not None else '?'
  arr.append(name);imports.append((dll,name))
 pos+=20
(out/'imports.csv').write_text('dll,function\n'+''.join(f'{x},{y}\n' for x,y in imports),encoding='utf-8')
# Extract all printable strings (minimum 7) to separate file with address
string_pat=re.compile(rb'[\x20-\x7e]{7,}')
strings=[]
for s in sects:
 if s['name'] not in ('.rdata','.data'):continue
 raw=b[s['file_offset']:s['file_offset']+s['raw_bytes']]
 for m in string_pat.finditer(raw):
  st=m.group(0).decode('ascii','replace')
  strings.append((ibase+s['rva']+m.start(),st))
(out/'native_strings_ascii.tsv').write_text('VA\tSTRING\n'+''.join('0x%x\t%s\n'%(a,txt[:2000].replace('\t','\\t').replace('\r','\\r').replace('\n','\\n')) for a,txt in strings),encoding='utf-8')
# UTF-16LE printable runs
utf16pat=re.compile(rb'(?:[\x20-\x7e]\x00){6,}')
ws=[]
for s in sects:
 if s['name'] not in ('.rdata','.data'):continue
 raw=b[s['file_offset']:s['file_offset']+s['raw_bytes']]
 for m in utf16pat.finditer(raw):ws.append((ibase+s['rva']+m.start(),m.group().decode('utf-16le')))
(out/'native_strings_utf16.tsv').write_text('VA\tSTRING\n'+''.join('0x%x\t%s\n'%(a,txt[:2000]) for a,txt in ws),encoding='utf-8')
# Important names (source strings). Use conservative keywords
pattern=re.compile(r'(fortnite|xinput|sinum|echo-client|\.pak\b|engine\.ini|manifest\.json|\beac\b|noeac|anticheat|anti.cheat|injection|inject|launch_game|verify_game|discord_rpc|hwid|hardware|diagnostic|sentinel|process hacker|taskkill|powershell|win64|logfile|createprocess|\bpatch(?:ed|ing)?\b)',re.I)
interesting=[(a,s) for a,s in strings if len(s)<2200 and pattern.search(s)]
# Cross reference index from linear disassembly to data VA and native function
xref={}; matches=collections.Counter();re_line=re.compile(r'^\s*([0-9a-f]+):\s*(.*?)\s*# 0x([0-9a-f]+)\s*$')
r_lo=ibase+next(s for s in sects if s['name']=='.rdata')['rva'];r_hi=r_lo+next(s for s in sects if s['name']=='.rdata')['memory_bytes']
loc_by_function=collections.defaultdict(list)
count=0
with asm.open(encoding='utf-8',errors='replace') as f:
 for line in f:
  m=re_line.match(line)
  if not m:continue
  instr=int(m.group(1),16);t=int(m.group(3),16)
  if not r_lo<=t<=r_hi:continue
  label=get_ascii_va(t,200)
  if not label:continue
  count+=1
  fi=bisect.bisect_right(starts,instr)-1
  if fi<0 or not unique[fi][0]<=instr<unique[fi][1]:continue
  funcstart=unique[fi][0]
  entry=(f'0x{instr:x}',f'0x{t:x}',label[:200].replace('\n','\\n'),m.group(2).strip())
  if pattern.search(label):
   loc_by_function[funcstart].append(entry)
   matches[label[:100]]+=1
# Output XREF relevant
with (out/'interesting_string_xrefs.tsv').open('w',encoding='utf-8') as f:
 f.write('function_start_va\tinstruction_va\tdata_va\tstring\tassembly\n')
 for a,entries in sorted(loc_by_function.items()):
  for e in entries:
   f.write('0x%x\t%s\t%s\t%s\t%s\n'%(a,*e))
# Focus: select func hits ranked by count / key quality, cap size and total
ranked=sorted(loc_by_function.items(), key=lambda item:(-len(item[1]),item[0]))
selected=set();bytes_selected=0
for addr,entries in ranked:
 i=bisect.bisect_left(starts,addr);length=unique[i][1]-addr
 if length>18000 or bytes_selected+length>1_600_000:continue
 selected.add(addr);bytes_selected+=length
 if len(selected)>=220:break
# Disassembly targeted: stream one pass and save only function ranges
lines_by_func=collections.defaultdict(list);re_inst=re.compile(r'^\s*([0-9a-f]+):')
with asm.open(encoding='utf-8',errors='replace') as f:
 for line in f:
  m=re_inst.match(line)
  if not m:continue
  addr=int(m.group(1),16)
  fi=bisect.bisect_right(starts,addr)-1
  if fi<0:continue
  start,end,_=unique[fi]
  if start in selected and start<=addr<end:lines_by_func[start].append(line)
with (out/'selected_functions_disassembly.asm').open('w',encoding='utf-8') as f:
 f.write('; Functions selected by read-only cross references to important strings.\n')
 for addr in sorted(selected):
  i=bisect.bisect_left(starts,addr);end=unique[i][1];f.write('\n; ------------ 0x%x..0x%x ------------------\n'%(addr,end))
  for e in loc_by_function[addr][:12]:f.write('; XREF %s: %s\n'%(e[0],e[2]))
  f.writelines(lines_by_func[addr])
summary={'sha256':hashlib.sha256(b).hexdigest(),'base_va':hex(ibase),'sections':sects,'exception_records':len(ranges),'unique_pdata_functions':len(unique),'imported_functions':len(imports),'ascii_strings':len(strings),'utf16_strings':len(ws),'interesting_strings':len(interesting),'resolved_interesting_function_xrefs':len(loc_by_function),'selected_function_count':len(selected),'total_selected_code_bytes':bytes_selected,'xrefs_in_rdata':count,'most_referenced_relevant_strings':matches.most_common(90)}
(out/'rust_native_summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
(out/'interesting_strings.txt').write_text(''.join('0x%x\t%s\n'%(addr,s.replace('\n','\\n')[:1000]) for addr,s in interesting),encoding='utf-8')
print({k:v for k,v in summary.items() if k not in ('sections','most_referenced_relevant_strings')})
