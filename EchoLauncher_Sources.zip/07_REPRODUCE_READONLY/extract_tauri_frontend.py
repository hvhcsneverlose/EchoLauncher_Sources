#!/usr/bin/env python3
"""Read-only extraction of Tauri Brotli-compressed frontend assets from a PE.
Compressed assets are embedded immediately following their path string.
No executable is launched.
"""
import brotli,hashlib,json,re,pathlib,sys,time
src=pathlib.Path(sys.argv[1]); dst=pathlib.Path(sys.argv[2]); data=src.read_bytes()
pat=re.compile(rb'/(?:assets/)?[A-Za-z0-9_.\-/]{1,90}\.(?:js|css|html|json|svg|png|jpg|jpeg|gif|woff2|woff|ttf|mp3|ico|webp|bmp|otf|exe|gif|wav|ogg)')
records=[]; old=set()

def test(start,end):
    z=brotli.Decompressor()
    try:
        z.process(data[start:end])
        return True, z.is_finished()
    except brotli.error:return False,False

def findstream(start,max_probe=5_000_000):
    # Bounded 4096-byte scan until the compressed data ends, then binary-search exact end.
    low=start; hi=None
    z=brotli.Decompressor(); chunk=4096
    for x in range(start,min(len(data),start+max_probe),chunk):
        try:
            z.process(data[x:x+chunk])
            if z.is_finished():
                low=x+chunk;break
        except brotli.error:
            hi=x+chunk;low=x;break
    if hi is None:
        # stream may have finished at a chunk boundary
        if low==start:return None
        hi=low+chunk
    # Binary search greatest valid prefix of compressed stream
    left=low; right=min(hi,len(data))
    valid,done=test(start,left)
    if not valid:
        left=start
    while right-left>1:
        mid=(left+right)//2
        v,f=test(start,mid)
        if v:left=mid
        else:right=mid
    v,f=test(start,left)
    if not(v and f):return None
    try:raw=brotli.decompress(data[start:left])
    except brotli.error:return None
    return left,raw

for mt in pat.finditer(data):
    nm=mt.group().decode('ascii','ignore')
    if nm.startswith('//') or 'docs.rs/' in nm or nm.count('/')>8:continue
    if nm in old:continue
    start=mt.end()
    # Brotli streams often start with \x1b or \x8b. False positives are checked by decoder.
    if data[start] not in (0x1b,0x8b,0xcb,0xab,0x5b,0x2b,0x9b):continue
    found=findstream(start)
    if not found:continue
    end,raw=found
    if len(raw)<32:continue
    # Validate signature for common file formats; JS/CSS should be decodable text
    ext=pathlib.PurePosixPath(nm).suffix
    if ext in ('.js','.css','.html','.json','.svg'):
        try:raw.decode('utf-8')
        except UnicodeDecodeError:continue
    safe=nm.lstrip('/')
    out=dst/'frontend'/safe
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_bytes(raw)
    rec={'path':safe, 'offset_in_exe':hex(start),'compressed_bytes':end-start,'extracted_bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    records.append(rec);old.add(nm)
    print('OK',safe,len(raw),'bytes')

(dst/'reports').mkdir(parents=True,exist_ok=True)
(dst/'reports'/'extraction_manifest.json').write_text(json.dumps({'source_sha256':hashlib.sha256(data).hexdigest(),'files':records},indent=2,ensure_ascii=False),encoding='utf-8')
print('TOTAL',len(records),'files',sum(x['extracted_bytes'] for x in records),'bytes')
