#!/usr/bin/env python3
"""Read-only PE/.NET metadata and IL dump (limited C# signature inference, no execution)."""
import struct,json,pathlib,sys,re,hashlib
inp=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
b=inp.read_bytes();u16=lambda o:struct.unpack_from('<H',b,o)[0];u32=lambda o:struct.unpack_from('<I',b,o)[0];u64=lambda o:struct.unpack_from('<Q',b,o)[0]
pe=u32(0x3c); coff=pe+4; secn=u16(coff+2); os=coff+20; om=u16(os); dd=os+(112 if om==0x20b else 96); nsec=os+u16(coff+16)
secs=[]
for i in range(secn):
 o=nsec+i*40; secs.append(dict(name=b[o:o+8].rstrip(b'\0').decode('ascii','replace'),vsz=u32(o+8),rva=u32(o+12),raw_size=u32(o+16),off=u32(o+20)))
def off(rva):
 if rva==0:return 0
 for s in secs:
  if s['rva']<=rva<s['rva']+max(s['raw_size'],s['vsz']):return s['off']+rva-s['rva']
 raise ValueError(f'RVA {rva:x} not found')
clr_rva=u32(dd+14*8);cl=off(clr_rva)
md_rva=u32(cl+8);md_size=u32(cl+12);md=off(md_rva)
assert b[md:md+4]==b'BSJB'
verlen=u32(md+12);streams_offset=md+16+verlen;streams_offset=(streams_offset+3)//4*4;flags=u16(streams_offset);stream_count=u16(streams_offset+2);cur=streams_offset+4
streams={}
for i in range(stream_count):
 start=u32(cur);size=u32(cur+4); p=cur+8; q=b.index(0,p);name=b[p:q].decode('ascii');cur=(q+4)//4*4
 streams[name]=(md+start,size)
strings=streams['#Strings'][0]; blob=streams['#Blob'][0];us=streams.get('#US',(0,0))[0]
def getstr(i):
 if not i:return ''
 p=strings+i
 try:return b[p:b.index(0,p)].decode('utf-8','replace')
 except:return ''
def comp_len(at):
 v=b[at]
 if v&128==0:return v,1
 if v&192==128:return ((v&0x3f)<<8)|b[at+1],2
 return ((v&0x1f)<<24)|b[at+1]<<16|b[at+2]<<8|b[at+3],4
def getblob(i):
 if not i:return b''
 p=blob+i;n,k=comp_len(p);return b[p+k:p+k+n]
mt=streams.get('#~',streams.get('#-'))[0]; heapflag=b[mt+6]; valid=u64(mt+8);p=mt+24
counts={}
for t in range(64):
 if valid>>t&1:counts[t]=u32(p);p+=4
names={0:'Module',1:'TypeRef',2:'TypeDef',3:'FieldPtr',4:'Field',5:'MethodPtr',6:'MethodDef',7:'ParamPtr',8:'Param',9:'InterfaceImpl',10:'MemberRef',11:'Constant',12:'CustomAttribute',13:'FieldMarshal',14:'DeclSecurity',15:'ClassLayout',16:'FieldLayout',17:'StandAloneSig',18:'EventMap',19:'EventPtr',20:'Event',21:'PropertyMap',22:'PropertyPtr',23:'Property',24:'MethodSemantics',25:'MethodImpl',26:'ModuleRef',27:'TypeSpec',28:'ImplMap',29:'FieldRVA',30:'ENCLog',31:'ENCMap',32:'Assembly',33:'AssemblyProcessor',34:'AssemblyOS',35:'AssemblyRef',36:'AssemblyRefProcessor',37:'AssemblyRefOS',38:'File',39:'ExportedType',40:'ManifestResource',41:'NestedClass',42:'GenericParam',43:'MethodSpec',44:'GenericParamConstraint'}
coded={'TypeDefOrRef':(2,[2,1,27]),'HasConstant':(2,[4,8,23]),'HasCustomAttribute':(5,[6,4,1,2,8,9,10,0,14,23,20,17,26,27,32,35,38,39,40,42,44,43]),'HasFieldMarshal':(1,[4,8]),'HasDeclSecurity':(2,[2,6,32]),'MemberRefParent':(3,[2,1,26,6,27]),'HasSemantics':(1,[20,23]),'MethodDefOrRef':(1,[6,10]),'MemberForwarded':(1,[4,6]),'Implementation':(2,[38,35,39]),'CustomAttributeType':(3,[None,None,6,10]),'ResolutionScope':(2,[0,26,35,1]),'TypeOrMethodDef':(1,[2,6])}
# column descriptor prefixes: u2,u4,str,blob,guid, table tNN, coded cName
spec={
0:['u2','str','guid','guid','guid'],1:['cResolutionScope','str','str'],2:['u4','str','str','cTypeDefOrRef','t4','t6'],3:['t4'],4:['u2','str','blob'],5:['t6'],6:['u4','u2','u2','str','blob','t8'],7:['t8'],8:['u2','u2','str'],9:['t2','cTypeDefOrRef'],10:['cMemberRefParent','str','blob'],11:['u2','cHasConstant','blob'],12:['cHasCustomAttribute','cCustomAttributeType','blob'],13:['cHasFieldMarshal','blob'],14:['u2','cHasDeclSecurity','blob'],15:['u2','u4','t2'],16:['u4','t4'],17:['blob'],18:['t2','t20'],19:['t20'],20:['u2','str','cTypeDefOrRef'],21:['t2','t23'],22:['t23'],23:['u2','str','blob'],24:['u2','t6','cHasSemantics'],25:['t2','cMethodDefOrRef','cMethodDefOrRef'],26:['str'],27:['blob'],28:['u2','cMemberForwarded','str','t26'],29:['u4','t4'],30:['u4','u4'],31:['u4'],32:['u4','u2','u2','u2','u2','u4','blob','str','str'],33:['u4'],34:['u4','u4','u4'],35:['u2','u2','u2','u2','u4','blob','str','str','blob'],36:['u4','t35'],37:['u4','u4','u4','t35'],38:['u4','str','blob'],39:['u4','u4','str','str','cImplementation'],40:['u4','u4','str','cImplementation'],41:['t2','t2'],42:['u2','u2','cTypeOrMethodDef','str'],43:['cMethodDefOrRef','blob'],44:['t42','cTypeDefOrRef']}
def colsize(k):
 if k=='u2':return 2
 if k=='u4':return 4
 if k=='str':return 4 if heapflag&1 else 2
 if k=='guid':return 4 if heapflag&2 else 2
 if k=='blob':return 4 if heapflag&4 else 2
 if k.startswith('t'):return 4 if counts.get(int(k[1:]),0)>=65536 else 2
 if k.startswith('c'):
  bits,ts=coded[k[1:]]
  return 4 if max([counts.get(t,0) for t in ts if t is not None],default=0)>=(1<<(16-bits)) else 2
 raise ValueError(k)
tables={};locations={}
for t in range(64):
 if t not in counts:continue
 if t not in spec:raise ValueError(('unknown metadata table',t))
 cs=spec[t];rsize=sum(map(colsize,cs));locations[t]=(p,rsize)
 if t in (0,1,2,4,6,8,10,17,20,23,26,27,28,32,35,40,41):
  rs=[]
  for i in range(counts[t]):
   st=p+i*rsize; z=[];q=st
   for k in cs:
    sz=colsize(k);val=int.from_bytes(b[q:q+sz],'little');q+=sz;z.append(val)
   rs.append(z)
  tables[t]=rs
 p+=counts[t]*rsize
refs=tables.get(1,[]);types=tables.get(2,[]);methods=tables.get(6,[]);members=tables.get(10,[]);fields=tables.get(4,[])
def fullname(r):
 return (getstr(r[2])+'.' if r[2] else '')+getstr(r[1])
name_types={};
for i,r in enumerate(refs,1):name_types[(1,i)]=fullname(r)
for i,r in enumerate(types,1):name_types[(2,i)]=fullname(r)
def gettypecoded(code):
 x=code&3;id=code>>2
 return name_types.get(([2,1,27][x],id),f'TypeToken({code})') if x<3 else '?'
# compressed int parser & signature parser
builtin={1:'void',2:'bool',3:'char',4:'sbyte',5:'byte',6:'short',7:'ushort',8:'int',9:'uint',10:'long',11:'ulong',12:'float',13:'double',14:'string',15:'pointer',16:'byref',17:'valuetype',18:'class',19:'generic',20:'array',22:'typedref',24:'IntPtr',25:'UIntPtr',28:'object',29:'szarray',30:'method',31:'modreq',32:'modopt'}
def parsesig(data):
 if not data:return '?()'
 idx=[0]
 def nr():
  if idx[0]>=len(data):return 0
  v,n=comp_len_custom(data,idx[0]);idx[0]+=n;return v
 def t(d=0):
  if d>15 or idx[0]>=len(data):return '?'
  v=data[idx[0]];idx[0]+=1
  if v in (18,17):return gettypecoded(nr())
  if v==29:return t(d+1)+'[]'
  if v==15:return t(d+1)+'*'
  if v==16:return 'ref '+t(d+1)
  if v==19:return '!'+str(nr())
  if v==30:return '!!'+str(nr())
  if v==21:
   class_code=data[idx[0]];idx[0]+=1
   nom=gettypecoded(nr()); n=nr();return nom+'<'+', '.join(t(d+1) for _ in range(min(n,16)))+'>'
  return builtin.get(v,f'TYPE_{v:02x}')
 try:
  call=data[idx[0]];idx[0]+=1
  if call&0x10:nr()
  ar=nr();res=t();args=[t() for _ in range(min(ar,100))]
  return res+' ('+', '.join(args)+')'
 except Exception:return 'sig='+data.hex()[:80]
def comp_len_custom(raw,at):
 v=raw[at]
 if v&128==0:return v,1
 if v&192==128:return ((v&0x3f)<<8)|raw[at+1],2
 return ((v&0x1f)<<24)|raw[at+1]<<16|raw[at+2]<<8|raw[at+3],4
methods_info=[]
for i,r in enumerate(methods,1):
 rv,imp,flag,n,sig,firstp=r
 owner=None
 for j,t in enumerate(types):
  if t[5]<=i<(types[j+1][5] if j+1<len(types) else len(methods)+1):owner=name_types[(2,j+1)];break
 methods_info.append(dict(row=i,token=f'0x060000{i:02x}',rva=f'0x{rv:08x}',file_offset=f'0x{off(rv):x}' if rv else None,name=getstr(n),owner=owner or '?',signature=parsesig(getblob(sig)),flags=flag,impl_flags=imp,parameters=firstp))
# IL opcodes table (single and prefixed) operand format: none, i1, i4, i8, r4,r8, branch1, branch4, switch, token, var1, var2
op={0x00:('nop','none'),0x01:('break','none'),0x02:('ldarg.0','none'),0x03:('ldarg.1','none'),0x04:('ldarg.2','none'),0x05:('ldarg.3','none'),0x06:('ldloc.0','none'),0x07:('ldloc.1','none'),0x08:('ldloc.2','none'),0x09:('ldloc.3','none'),0x0a:('stloc.0','none'),0x0b:('stloc.1','none'),0x0c:('stloc.2','none'),0x0d:('stloc.3','none'),0x0e:('ldarg.s','var1'),0x0f:('ldarga.s','var1'),0x10:('starg.s','var1'),0x11:('ldloc.s','var1'),0x12:('ldloca.s','var1'),0x13:('stloc.s','var1'),0x14:('ldnull','none'),0x15:('ldc.i4.m1','none'),0x16:('ldc.i4.0','none'),0x17:('ldc.i4.1','none'),0x18:('ldc.i4.2','none'),0x19:('ldc.i4.3','none'),0x1a:('ldc.i4.4','none'),0x1b:('ldc.i4.5','none'),0x1c:('ldc.i4.6','none'),0x1d:('ldc.i4.7','none'),0x1e:('ldc.i4.8','none'),0x1f:('ldc.i4.s','i1'),0x20:('ldc.i4','i4'),0x21:('ldc.i8','i8'),0x22:('ldc.r4','r4'),0x23:('ldc.r8','r8'),0x25:('dup','none'),0x26:('pop','none'),0x27:('jmp','token'),0x28:('call','token'),0x29:('calli','token'),0x2a:('ret','none'),0x2b:('br.s','branch1'),0x2c:('brfalse.s','branch1'),0x2d:('brtrue.s','branch1'),0x2e:('beq.s','branch1'),0x2f:('bge.s','branch1'),0x30:('bgt.s','branch1'),0x31:('ble.s','branch1'),0x32:('blt.s','branch1'),0x33:('bne.un.s','branch1'),0x34:('bge.un.s','branch1'),0x35:('bgt.un.s','branch1'),0x36:('ble.un.s','branch1'),0x37:('blt.un.s','branch1'),0x38:('br','branch4'),0x39:('brfalse','branch4'),0x3a:('brtrue','branch4'),0x3b:('beq','branch4'),0x3c:('bge','branch4'),0x3d:('bgt','branch4'),0x3e:('ble','branch4'),0x3f:('blt','branch4'),0x40:('bne.un','branch4'),0x41:('bge.un','branch4'),0x42:('bgt.un','branch4'),0x43:('ble.un','branch4'),0x44:('blt.un','branch4'),0x45:('switch','switch'),0x46:('ldind.i1','none'),0x47:('ldind.u1','none'),0x48:('ldind.i2','none'),0x49:('ldind.u2','none'),0x4a:('ldind.i4','none'),0x4b:('ldind.u4','none'),0x4c:('ldind.i8','none'),0x4d:('ldind.i','none'),0x4e:('ldind.r4','none'),0x4f:('ldind.r8','none'),0x50:('ldind.ref','none'),0x51:('stind.ref','none'),0x52:('stind.i1','none'),0x53:('stind.i2','none'),0x54:('stind.i4','none'),0x55:('stind.i8','none'),0x56:('stind.r4','none'),0x57:('stind.r8','none'),0x58:('add','none'),0x59:('sub','none'),0x5a:('mul','none'),0x5b:('div','none'),0x5c:('div.un','none'),0x5d:('rem','none'),0x5e:('rem.un','none'),0x5f:('and','none'),0x60:('or','none'),0x61:('xor','none'),0x62:('shl','none'),0x63:('shr','none'),0x64:('shr.un','none'),0x65:('neg','none'),0x66:('not','none'),0x67:('conv.i1','none'),0x68:('conv.i2','none'),0x69:('conv.i4','none'),0x6a:('conv.i8','none'),0x6b:('conv.r4','none'),0x6c:('conv.r8','none'),0x6d:('conv.u4','none'),0x6e:('conv.u8','none'),0x6f:('callvirt','token'),0x70:('cpobj','token'),0x71:('ldobj','token'),0x72:('ldstr','token'),0x73:('newobj','token'),0x74:('castclass','token'),0x75:('isinst','token'),0x76:('conv.r.un','none'),0x79:('unbox','token'),0x7a:('throw','none'),0x7b:('ldfld','token'),0x7c:('ldflda','token'),0x7d:('stfld','token'),0x7e:('ldsfld','token'),0x7f:('ldsflda','token'),0x80:('stsfld','token'),0x81:('stobj','token'),0x82:('conv.ovf.i1.un','none'),0x83:('conv.ovf.i2.un','none'),0x84:('conv.ovf.i4.un','none'),0x85:('conv.ovf.i8.un','none'),0x86:('conv.ovf.u1.un','none'),0x87:('conv.ovf.u2.un','none'),0x88:('conv.ovf.u4.un','none'),0x89:('conv.ovf.u8.un','none'),0x8a:('conv.ovf.i.un','none'),0x8b:('conv.ovf.u.un','none'),0x8c:('box','token'),0x8d:('newarr','token'),0x8e:('ldlen','none'),0x8f:('ldelema','token'),0x90:('ldelem.i1','none'),0x91:('ldelem.u1','none'),0x92:('ldelem.i2','none'),0x93:('ldelem.u2','none'),0x94:('ldelem.i4','none'),0x95:('ldelem.u4','none'),0x96:('ldelem.i8','none'),0x97:('ldelem.i','none'),0x98:('ldelem.r4','none'),0x99:('ldelem.r8','none'),0x9a:('ldelem.ref','none'),0x9b:('stelem.i','none'),0x9c:('stelem.i1','none'),0x9d:('stelem.i2','none'),0x9e:('stelem.i4','none'),0x9f:('stelem.i8','none'),0xa0:('stelem.r4','none'),0xa1:('stelem.r8','none'),0xa2:('stelem.ref','none'),0xa3:('ldelem','token'),0xa4:('stelem','token'),0xa5:('unbox.any','token'),0xb3:('conv.ovf.i1','none'),0xb4:('conv.ovf.u1','none'),0xb5:('conv.ovf.i2','none'),0xb6:('conv.ovf.u2','none'),0xb7:('conv.ovf.i4','none'),0xb8:('conv.ovf.u4','none'),0xb9:('conv.ovf.i8','none'),0xba:('conv.ovf.u8','none'),0xc2:('refanyval','token'),0xc3:('ckfinite','none'),0xc6:('mkrefany','token'),0xd0:('ldtoken','token'),0xd1:('conv.u2','none'),0xd2:('conv.u1','none'),0xd3:('conv.i','none'),0xd4:('conv.ovf.i','none'),0xd5:('conv.ovf.u','none'),0xd6:('add.ovf','none'),0xd7:('add.ovf.un','none'),0xd8:('mul.ovf','none'),0xd9:('mul.ovf.un','none'),0xda:('sub.ovf','none'),0xdb:('sub.ovf.un','none'),0xdc:('endfinally','none'),0xdd:('leave','branch4'),0xde:('leave.s','branch1'),0xdf:('stind.i','none'),0xe0:('conv.u','none')}
for code,name,ty in [(0x00,'arglist','none'),(0x01,'ceq','none'),(0x02,'cgt','none'),(0x03,'cgt.un','none'),(0x04,'clt','none'),(0x05,'clt.un','none'),(0x06,'ldftn','token'),(0x07,'ldvirtftn','token'),(0x09,'ldarg','var2'),(0x0a,'ldarga','var2'),(0x0b,'starg','var2'),(0x0c,'ldloc','var2'),(0x0d,'ldloca','var2'),(0x0e,'stloc','var2'),(0x0f,'localloc','none'),(0x11,'endfilter','none'),(0x12,'unaligned.','var1'),(0x13,'volatile.','none'),(0x14,'tail.','none'),(0x15,'initobj','token'),(0x16,'constrained.','token'),(0x17,'cpblk','none'),(0x18,'initblk','none'),(0x1a,'rethrow','none'),(0x1c,'sizeof','token'),(0x1d,'refanytype','none'),(0x1e,'readonly.','none')]:op[0xfe00+code]=(name,ty)
def tokenname(v):
 tab=v>>24;row=v&0xffffff
 if tab==0x70 and us:
  try:
   start=us+row;n,k=comp_len(start);return '"'+b[start+k:start+k+n].decode('utf-16le','replace').rstrip('\ufffd\x00')+'"'
  except:return '?US'
 if tab==6 and 1<=row<=len(methods_info):
  m=methods_info[row-1];return m['owner']+'::'+m['name']
 if tab==10 and 1<=row<=len(members):
  r=members[row-1];par=r[0];t=par&7;i=par>>3
  parent= name_types.get(([2,1,26,6,27][t],i),'?') if t<5 else '?'
  return parent+'::'+getstr(r[1])
 if tab==1 and 1<=row<=len(refs):return fullname(refs[row-1])
 if tab==2 and 1<=row<=len(types):return fullname(types[row-1])
 if tab==4 and 1<=row<=len(fields):return getstr(fields[row-1][1])
 return f'0x{v:08x}'
output=[];invalid=[];code_bytes=0
for mi in methods_info:
 r=methods[mi['row']-1];rv=r[0];name=f"{mi['owner']}::{mi['name']}"
 output.append(f'\n// Method {mi["token"]} {name}: {mi["signature"]} | RVA {mi["rva"]}\n')
 if rv==0:output.append('// No IL body (abstract, extern, or internal)\n');continue
 po=off(rv);head=b[po]
 if head&3==2:
  ilstart=po+1;ilsize=head>>2
 elif head&3==3:
  hsize=((u16(po)>>12)&0xf)*4;ilsize=u32(po+4);ilstart=po+hsize
 else:output.append('// Invalid method body header\n');invalid.append((name,'header'));continue
 mi['il_size']=ilsize;code_bytes+=ilsize;code=b[ilstart:ilstart+ilsize];q=0
 while q<len(code):
  start=q;opcode=code[q];q+=1
  if opcode==0xfe:
   if q>=len(code):break
   opcode=0xfe00+code[q];q+=1
  opname,kind=op.get(opcode,(f'UNKNOWN_{opcode:04x}','none'))
  value=''
  try:
   if kind in ('i1','var1','branch1'):
    v=struct.unpack_from('<b' if kind!='var1' else '<B',code,q)[0];q+=1;value=f' IL_{(q+v):04x}' if kind=='branch1' else str(v)
   elif kind in ('i4','branch4'):
    v=struct.unpack_from('<i',code,q)[0];q+=4;value=f' IL_{(q+v):04x}' if kind=='branch4' else str(v)
   elif kind in ('token','r4'):
    v=struct.unpack_from('<I',code,q)[0];q+=4
    value=f'0x{v:08x}  // {tokenname(v)}' if kind=='token' else str(struct.unpack('<f',struct.pack('<I',v))[0])
   elif kind in ('i8','r8'):
    value=str(struct.unpack_from('<q' if kind=='i8' else '<d',code,q)[0]);q+=8
   elif kind=='var2':value=str(struct.unpack_from('<H',code,q)[0]);q+=2
   elif kind=='switch':
    n=struct.unpack_from('<I',code,q)[0];q+=4
    if n>10000:raise ValueError('excessive switch')
    positions=struct.unpack_from('<'+'i'*n,code,q);q+=4*n
    value=', '.join('IL_%04x'%(q+v) for v in positions)
  except (struct.error,ValueError):invalid.append((name,f'IL_{start:04x}'));value='[ERROR]';q=len(code)
  output.append(f'  IL_{start:04x}: {opname:<20} {value}\n')
(out/'FortniteLauncher_all_methods.il').write_text(''.join(output),encoding='utf-8')
classes=[]
for idx,t in enumerate(types):
 type_name=name_types[(2,idx+1)]
 method_ids=list(range(t[5], (types[idx+1][5] if idx+1<len(types) else len(methods)+1)))
 classes.append(dict(type=type_name,flags=t[0],base=gettypecoded(t[3]),method_count=len(method_ids),methods=[methods_info[i-1] for i in method_ids]))
(out/'classes_and_methods.json').write_text(json.dumps(classes,indent=2,ensure_ascii=False),encoding='utf-8')
(out/'metadata.json').write_text(json.dumps(dict(file=inp.name,sha256=hashlib.sha256(b).hexdigest(),clr_rva=f'0x{clr_rva:x}',sections=secs,streams={k:dict(offset=f'0x{v[0]:x}',size=v[1]) for k,v in streams.items()},tables={names.get(t,t):n for t,n in counts.items()},assembly_name=getstr(tables[32][0][7]) if 32 in tables else '',assembly_refs=[getstr(x[6]) for x in tables.get(35,[])],methods=len(methods_info),total_il_bytes=code_bytes,invalid=invalid),indent=2,ensure_ascii=False),encoding='utf-8')
print('DOTNET', 'types',len(types),'methods',len(methods_info),'IL bytes',code_bytes,'errors',len(invalid));print('class names:',[c['type'] for c in classes])
